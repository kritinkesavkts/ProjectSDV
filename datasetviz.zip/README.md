An example showing the capabilities of VizHub:

- Loads D3 via UNPKG.
- Demonstrates use of `import` from `"d3"`.
- Demonstrates use of `import` from local ES6 modules.
