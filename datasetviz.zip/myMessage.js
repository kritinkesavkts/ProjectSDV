// This is an example of an ES6 module.
export const message = 'Hello VizHub!';
