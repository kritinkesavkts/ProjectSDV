// Define the SVG containers for both visualizations
const svg1 = d3
  .select('#my_dataviz1')
  .append('svg')
  .attr('width', 460)
  .attr('height', 400)
  .append('g')
  .attr('transform', 'translate(40,20)');

const svg2 = d3
  .select('#my_dataviz2')
  .append('svg')
  .attr('width', 960)
  .attr('height', 500)
  .append('g')
  .attr('transform', 'translate(50,30)');

// Load data from GitHub URL for Salary Data Visualization
d3.csv(
  'https://raw.githubusercontent.com/kritinkesavkts/ProjectSDV/main/ds_salaries%20(2).csv',
).then(function (data) {
  // Process salary data
  const salaryData = data.map((d) => ({
    experience_level: d.experience_level,
    salary_in_usd: +d.salary_in_usd,
  }));

  // Group data by experience level and calculate average salary
  const salaryAvgByExperience = Array.from(
    d3.group(salaryData, (d) => d.experience_level),
    ([key, value]) => ({
      key,
      value: d3.mean(value, (d) => d.salary_in_usd),
    }),
  );

  // Create scales
  const y = d3
    .scaleBand()
    .domain(salaryAvgByExperience.map((d) => d.key))
    .range([0, 360])
    .padding(0.1);

  const x = d3
    .scaleLinear()
    .domain([
      0,
      d3.max(salaryAvgByExperience, (d) => d.value),
    ])
    .range([0, 400]);

  // Add axes
  svg1.append('g').call(d3.axisLeft(y));
  svg1
    .append('g')
    .attr('transform', 'translate(0,360)')
    .call(d3.axisBottom(x));

  // Add bars
  svg1
    .selectAll('.bar')
    .data(salaryAvgByExperience)
    .join('rect')
    .attr('class', 'bar')
    .attr('y', (d) => y(d.key))
    .attr('height', y.bandwidth())
    .attr('x', 0)
    .attr('width', (d) => x(d.value))
    .attr('fill', '#69b3a2');
});

// Load combined data for Salary vs. COVID Cases Visualization
Promise.all([
  d3.csv(
    'https://raw.githubusercontent.com/kritinkesavkts/ProjectSDV/main/ds_salaries%20(2).csv',
  ),
  d3.csv(
    'https://raw.githubusercontent.com/kritinkesavkts/ProjectSDV/main/covid_data_post2021_march.csv',
  ),
]).then(function ([salaryData, covidData]) {
  // Process salary data
  const salaryAvgByYear = d3.rollups(
    salaryData,
    (v) => d3.mean(v, (d) => +d.salary_in_usd),
    (d) => d.work_year,
  );

  // Process COVID data to get total cases by year
  const covidCasesByYear = d3.rollups(
    covidData,
    (v) => d3.sum(v, (d) => +d.new_cases),
    (d) => d.date.slice(0, 4),
  );

  // Create scales
  const x = d3
    .scaleLinear()
    .domain(d3.extent(covidCasesByYear, (d) => +d[0]))
    .range([0, 900]);

  const yLeft = d3
    .scaleLinear()
    .domain([0, d3.max(salaryAvgByYear, (d) => d[1])])
    .range([450, 0]);

  const yRight = d3
    .scaleLinear()
    .domain([0, d3.max(covidCasesByYear, (d) => d[1])])
    .range([450, 0]);

  // Add axes
  svg2.append('g').call(d3.axisLeft(yLeft));
  svg2
    .append('g')
    .attr('transform', 'translate(900,0)')
    .call(d3.axisRight(yRight));
  svg2
    .append('g')
    .attr('transform', 'translate(0,450)')
    .call(d3.axisBottom(x));

  // Draw salary line
  const lineSalary = d3
    .line()
    .x((d) => x(+d[0]))
    .y((d) => yLeft(d[1]));

  svg2
    .append('path')
    .datum(salaryAvgByYear)
    .attr('fill', 'none')
    .attr('stroke', 'blue')
    .attr('stroke-width', 2)
    .attr('d', lineSalary);

  // Draw COVID line
  const lineCovid = d3
    .line()
    .x((d) => x(+d[0]))
    .y((d) => yRight(d[1]));

  svg2
    .append('path')
    .datum(covidCasesByYear)
    .attr('fill', 'none')
    .attr('stroke', 'red')
    .attr('stroke-width', 2)
    .attr('d', lineCovid);
});
